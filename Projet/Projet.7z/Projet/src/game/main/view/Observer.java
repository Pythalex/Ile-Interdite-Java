package game.main.view;

public interface Observer {

    public void update();

}
